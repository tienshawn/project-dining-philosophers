from dining_philosophers import GUI

def main():
    gui = GUI()
    gui.default_build()

if __name__ == "__main__":
    main()